# 任務：中華國中 114上・9年級・第3次

只認領 `1bzl5dOvIbwrYn2nZEy9Jlw3yS5qkl5Id`。請先讀本資料夾manifest與根目錄AI_PROMPT.md，再看original與全部pages。

回傳 `1bzl5dOvIbwrYn2nZEy9Jlw3yS5qkl5Id.md`，不能只回傳此空範本；必須包含全卷文字與唯一完整JSON區塊。
