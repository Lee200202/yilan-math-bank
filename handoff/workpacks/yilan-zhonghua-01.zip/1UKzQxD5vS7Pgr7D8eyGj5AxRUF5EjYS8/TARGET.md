# 任務：中華國中 114上・9年級・第2次

只認領 `1UKzQxD5vS7Pgr7D8eyGj5AxRUF5EjYS8`。請先讀本資料夾manifest與根目錄AI_PROMPT.md，再看original與全部pages。

回傳 `1UKzQxD5vS7Pgr7D8eyGj5AxRUF5EjYS8.md`，不能只回傳此空範本；必須包含全卷文字與唯一完整JSON區塊。
