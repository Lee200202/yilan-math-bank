# 內城國民中小學 110上・9年級・第3次

paperId: `nc-110-1-3-9`

## 卷首與來源核對

請核對manifest，填寫原卷全部頁碼；不得把預填declaredSlot當作實際卷首證據。

## 逐題全文

此處逐題列出可讀文字、公式、所有選項／填答格、難度、南一單元與來源頁。SVG完整放入下方JSON，不使用截圖代替。

## 原題盤點與未完成項目

請列原大題→題數、所有子題及原稿疑義。完成後將deliveryStatus改complete；未完成則partial並明列缺漏。

## 匯入資料（恰好一個JSON區塊）

```json
{
  "deliveryStatus": "draft",
  "paperId": "nc-110-1-3-9",
  "sourceSha256": "83385d0cf3d8cc2ce8362137f8f3b0b695167fa39e9d830774891e96aeb691e7",
  "printedHeader": "請實看卷首後填寫",
  "printedSlot": {
    "year": 110,
    "semester": 1,
    "grade": 9,
    "exam": 3
  },
  "printedCounts": "請逐頁盤點題型、題號與子題",
  "visualReviewComplete": false,
  "reviewNote": "請記錄看過的原卷頁、圖形、原稿疑義與未完成項目",
  "expectedTypes": {
    "choice": 0,
    "fill": 0,
    "written": 0
  },
  "questions": []
}
```
